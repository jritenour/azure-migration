require 'winrm'
ps_script = <<PS_SCRIPT
$result = @{}

Import-Module 'C:\\Program Files\\Microsoft Virtual Machine Converter\\MvmcCmdlet.psd1'

$sourceUser= 'administrator@vcenter.home.lab'
$sourcePassword = ConvertTo-SecureString 'Thebus36!' -AsPlainText -Force
$sourceCredential = New-Object PSCredential ($sourceUser, $sourcePassword)
$sourceConnection = New-MvmcSourceConnection -Server '192.168.2.23' -SourceCredential $sourceCredential -verbose

$sourceVM = Get-MvmcSourceVirtualMachine -SourceConnection $sourceConnection -verbose | where {$_.Name -match "converttest" }

$destinationLiteralPath = 'e:\\test' 
ConvertTo-MvmcVirtualHardDiskOvf -SourceConnection $sourceConnection -DestinationLiteralPath $destinationLiteralPath -GuestVmId $sourceVM.GuestVmId -vhdformat vhd

$result 

$result

PS_SCRIPT
 
url_params = {
  :ipaddress => '192.168.2.14',
  :port      => 5985                # Default port 5985
}

connect_params = {
  :user         => 'administrator',    # Example: domain\\user
  :pass         => 'Thebus36',
#  :disable_sspi => true
}

url = "http://#{url_params[:ipaddress]}:#{url_params[:port]}/wsman"
winrm   = WinRM::WinRMWebService.new(url, :negotiate, connect_params)
results=winrm.run_powershell_script(ps_script)

errors = results[:data].collect { |d| d[:stderr] }.join
$evm.log("error", "WinRM returned stderr: #{errors}") unless errors.blank?

data = results[:data].collect { |d| d[:stdout] }.join
$evm.log("info", "WinRM returned hash: #{data}") 
